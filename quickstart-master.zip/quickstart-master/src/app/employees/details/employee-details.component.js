"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var user_service_1 = require("../../EmployeeService/user.service");
var EmployeeDetailsComponent = (function () {
    function EmployeeDetailsComponent(us, ar) {
        var _this = this;
        this.us = us;
        this.ar = ar;
        var id = this.ar.snapshot.params['id'];
        this.us.getUserById(id).subscribe(function (objEmployee) {
            _this.employeeDetails = objEmployee;
        });
    }
    return EmployeeDetailsComponent;
}());
EmployeeDetailsComponent = __decorate([
    core_1.Component({
        selector: 'employee-details',
        template: "<div>\n                 <div>{{employeeDetails.id}}</div>\n                 <div>{{employeeDetails.name}}</div>\n                 <div>{{employeeDetails.designation}}</div>\n                 <div>{{employeeDetails.salary | currency : \"INR\" : true}}</div>\n               \n            </div>",
    }),
    __metadata("design:paramtypes", [user_service_1.UserService, router_1.ActivatedRoute])
], EmployeeDetailsComponent);
exports.EmployeeDetailsComponent = EmployeeDetailsComponent;
//# sourceMappingURL=employee-details.component.js.map