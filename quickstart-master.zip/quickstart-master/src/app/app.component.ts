import { Component,OnInit } from '@angular/core';
import { EmployeeListComponent } from './employees/employee-list.component'

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
})
export class AppComponent { 
  
}