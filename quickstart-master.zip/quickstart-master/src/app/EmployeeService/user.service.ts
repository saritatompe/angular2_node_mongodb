import { Injectable } from '@angular/core';
import {Employee} from '../employees/employee.component';
import { Http, Response, Headers,RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs';

@Injectable()
export class UserService {
  constructor (
    private http: Http
  ) {}

  getUser() {
    return this.http.get(`http://localhost:8080/employees`)
    .map((res:Response) => res.json());
  }
  
  getUserById(id:number) {
    return this.http.get(`http://localhost:8080/employees/`+id)
    .map((res:Response) => res.json());
  }

  saveWorkHoursService(employee:Employee)  {
    debugger
    var headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let options = new RequestOptions({ headers: headers });
    return this.http.post('http://localhost:8080/employees/updates', JSON.stringify(employee), options).map((res:Response) => res.json());;
  }
}