import { Component } from '@angular/core';
import { UserService } from '../EmployeeService/user.service'
import {Employee} from './employee.component';
@Component({
  selector: 'employee-list',
  templateUrl: './employee-list.component.html',
})
export class EmployeeListComponent { 
  employeeList: Array<any> = []
  showDialog = false;
  constructor(private us: UserService) {
    this.us.getUser().subscribe(employees => {
      this.employeeList = employees
    })
  }

  saveWorkHours(event : any, employee : Employee){
    debugger
   
    console.log(event.target.innerText,employee)
    employee.hoursWorked=Number(event.target.innerText);
    this.us.saveWorkHoursService(employee).subscribe(objEmployee => {
      employee = objEmployee;
  });
  }
  
}