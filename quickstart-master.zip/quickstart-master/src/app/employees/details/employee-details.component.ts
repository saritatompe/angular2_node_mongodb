import { Component,OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router'
import { UserService }  from '../../EmployeeService/user.service';
import {Employee} from '../employee.component';
@Component({
  selector: 'employee-details',
  template: `<div>
                 <div>{{employeeDetails.id}}</div>
                 <div>{{employeeDetails.name}}</div>
                 <div>{{employeeDetails.designation}}</div>
                 <div>{{employeeDetails.salary | currency : "INR" : true}}</div>
               
            </div>`,
})
export class EmployeeDetailsComponent { 
    employeeDetails: Employee 
    constructor(private us: UserService, private ar: ActivatedRoute) {
        let id = this.ar.snapshot.params['id'];   
        this.us.getUserById(id).subscribe(objEmployee => {
            this.employeeDetails = objEmployee;
        })
   }
  
}
