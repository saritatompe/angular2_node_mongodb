import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { EmployeeListComponent } from './employees/employee-list.component'

import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { SearchFilterPipe } from './filter/filterPipe.component';
import { RouterModule, Routes } from '@angular/router';
import { EmployeeDetailsComponent} from './employees/details/employee-details.component';
import { UserService} from './EmployeeService/user.service'
import { HighlightDirective} from './employees/directive/highlight.directive';
import { NewEmployeeComponent} from './employees/newEmployee/newEmployee.component';
const appRoutes: Routes = [
  
  { path: 'employees', component: EmployeeListComponent },
  { path: 'employees/:id', component: EmployeeDetailsComponent },
  
];
@NgModule({
  imports:      [ BrowserModule, FormsModule, HttpModule, RouterModule.forRoot(appRoutes) ],
  declarations: [ AppComponent, EmployeeListComponent, SearchFilterPipe, NewEmployeeComponent, EmployeeDetailsComponent,HighlightDirective ],
  providers: [UserService],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
