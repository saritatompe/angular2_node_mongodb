
import { Component, OnInit, Input, Output, OnChanges, EventEmitter, 
    trigger, state, style, animate, transition } from '@angular/core';
import {Employee} from '../../employees/employee.component';
@Component({
  selector: 'new-employee',
  templateUrl: './new-employee.component.html',
  animations: [
    trigger('dialog', [
      transition('void => *', [
        style({ transform: 'scale3d(.3, .3, .3)' }),
        animate(100)
      ]),
      transition('* => void', [
        animate(100, style({ transform: 'scale3d(.0, .0, .0)' }))
      ])
    ])
  ]
})
export class NewEmployeeComponent { 
    model :  Employee = new Employee;
    @Input() closable = true;
    @Input() visible: boolean;
    @Output() visibleChange: EventEmitter<boolean> = new EventEmitter<boolean>();
  
    constructor() { }
  
    ngOnInit() { }
  
    close() {
      this.visible = false;
      this.visibleChange.emit(this.visible);
    }
    user() {
      debugger;
       console.log(JSON.stringify(this.model)); }
   
}