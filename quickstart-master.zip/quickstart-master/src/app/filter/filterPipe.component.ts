import { Injectable, Pipe, PipeTransform } from '@angular/core';

@Pipe({
 name: 'searchfilter'
})

@Injectable()
export class SearchFilterPipe implements PipeTransform {
 transform(items: Array<any>, field: string, value: string): any[] {
  //  if (!items) return [];
  //  console.log(items.filter(it => it[field] == value));
  //  return items.filter(it => it[field] == value);
return ;
 }
}